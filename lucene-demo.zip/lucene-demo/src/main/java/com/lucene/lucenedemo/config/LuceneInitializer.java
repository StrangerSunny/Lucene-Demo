package com.lucene.lucenedemo.config;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.search.SearcherManager;
import org.apache.lucene.store.ByteBuffersDirectory;
import org.apache.lucene.store.Directory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;

@Configuration
public class LuceneInitializer {

    private static final Logger log = LoggerFactory.getLogger(LuceneInitializer.class);

    @Bean
    public IndexWriter indexWriter() throws IOException {
        log.info("------------------ Initializing Index Writer -----------------");
        Directory memoryIndex = new ByteBuffersDirectory();
        StandardAnalyzer analyzer = new StandardAnalyzer();
        IndexWriterConfig indexWriterConfig = new IndexWriterConfig(analyzer);
        return new IndexWriter(memoryIndex, indexWriterConfig);
    }

    @Bean
    public StandardAnalyzer analyzer() {
        return new StandardAnalyzer();
    }

    @Bean
    public SearcherManager searcherManager(IndexWriter indexWriter) throws IOException {
        log.info("------------------ Initializing Searcher Manager -----------------");
        return new SearcherManager(indexWriter, null);
    }
}
