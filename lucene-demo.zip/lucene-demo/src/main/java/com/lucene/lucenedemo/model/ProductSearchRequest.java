package com.lucene.lucenedemo.model;

import java.util.List;

public class ProductSearchRequest {
    private List<String> productIds;

    public ProductSearchRequest() {
    }

    public ProductSearchRequest(List<String> productIds) {
        this.productIds = productIds;
    }

    public List<String> getProductIds() {
        return productIds;
    }

    public void setProductIds(List<String> productIds) {
        this.productIds = productIds;
    }
}
