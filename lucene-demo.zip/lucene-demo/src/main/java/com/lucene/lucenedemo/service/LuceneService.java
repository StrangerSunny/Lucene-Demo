package com.lucene.lucenedemo.service;

import com.lucene.lucenedemo.model.Product;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class LuceneService {

    private final IndexWriter indexWriter;
    private final SearcherManager searcherManager;

    @Autowired
    public LuceneService(IndexWriter indexWriter, SearcherManager searcherManager) {
        this.indexWriter = indexWriter;
        this.searcherManager = searcherManager;
    }

    @Autowired
    private RestTemplate restTemplate;

    public List<Product> getProducts() {
        ResponseEntity<List<Product>> response = restTemplate.exchange(
                "http://localhost:3000/products",
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<List<Product>>() {}
        );
        return response.getBody();
    }

    public List<Document> searchByProductId(String productId) throws IOException {
        searcherManager.maybeRefresh();
        IndexSearcher searcher = searcherManager.acquire();
        List<Document> documents = new ArrayList<>();
        try {
            Query query = new TermQuery(new Term("PRODUCT_ID", productId));
            TopDocs topDocs = searcher.search(query, Integer.MAX_VALUE); // Retrieve all matching documents
            for (ScoreDoc scoreDoc : topDocs.scoreDocs) {
                documents.add(searcher.doc(scoreDoc.doc));
            }
        } finally {
            searcherManager.release(searcher);
        }
        return documents;
    }

    public List<Document> searchByProductIds(List<String> productIds) throws IOException {
        searcherManager.maybeRefresh();
        IndexSearcher searcher = searcherManager.acquire();
        List<Document> documents = new ArrayList<>();

        try {
            BooleanQuery.Builder booleanQueryBuilder = new BooleanQuery.Builder();

            for (String productId : productIds) {
                Query query = new TermQuery(new Term("PRODUCT_ID", productId));
                booleanQueryBuilder.add(query, BooleanClause.Occur.SHOULD);
            }

            BooleanQuery booleanQuery = booleanQueryBuilder.build();
            TopDocs topDocs = searcher.search(booleanQuery, productIds.size()); // Limiting to one record per product ID

            for (ScoreDoc scoreDoc : topDocs.scoreDocs) {
                documents.add(searcher.doc(scoreDoc.doc));
            }
        } finally {
            searcherManager.release(searcher);
        }

        return documents;
    }
}
