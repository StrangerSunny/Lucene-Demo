package com.lucene.lucenedemo.scheduler;

import com.lucene.lucenedemo.controller.ProductIndexer;
import com.lucene.lucenedemo.model.Product;
import com.lucene.lucenedemo.service.LuceneService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;

@EnableScheduling
@Component
public class ProductScheduler {
    private static final Logger LOGGER = LoggerFactory.getLogger(ProductScheduler.class);

    @Autowired
    private ProductIndexer productIndexer;

    @Autowired
    private LuceneService luceneService;

    @Scheduled(fixedRate = 30000) // 30 seconds
    public void fetchProducts() {
        LOGGER.info("--------------------- Scheduler started --------------");
        LOGGER.info("----------------------Indexing Started----------------");
        try {
            // Fetch products from Lucene service
            List<Product> products = luceneService.getProducts();
            if (products != null && !products.isEmpty()) {
                // Process the fetched products
                for (Product product : products) {
                    LOGGER.info("Fetched product: {}", product.toString());
                }
                productIndexer.refreshProductIndex();
            } else {
                LOGGER.info("No products fetched from Lucene service.");
            }
        } catch (Exception e) {
            LOGGER.error("Error fetching or indexing products: {}", e.getMessage());
        }
    }
}
