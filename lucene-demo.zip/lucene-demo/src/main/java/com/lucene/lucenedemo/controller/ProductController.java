package com.lucene.lucenedemo.controller;

import com.lucene.lucenedemo.model.Product;
import com.lucene.lucenedemo.model.ProductSearchRequest;
import com.lucene.lucenedemo.service.LuceneService;
import org.apache.lucene.document.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@RestController
public class ProductController {

    @Autowired
    private LuceneService luceneService;

    @GetMapping("/api/product")
    public List<Product> getProduct() {
        return luceneService.getProducts();
    }

    @GetMapping("/search")
    public List<Product> searchByProductId(@RequestParam String productId) throws IOException {
        List<Document> documents = luceneService.searchByProductId(productId);
        return documents.stream().map(this::convertDocumentToResponse).collect(Collectors.toList());
    }

    private Product convertDocumentToResponse(Document document) {
        return new Product(
                document.get("PRODUCT_ID"),
                document.get("PRODUCT_TITLE"),
                document.get("PRODUCT_DESCRIPTION"),
                document.get("PRODUCT_PRICE")
        );
    }

    @PostMapping("/searchList")
    public ResponseEntity<List<Document>> searchProducts(@RequestBody ProductSearchRequest request) {
        List<Document> documents;
        try {
            documents = luceneService.searchByProductIds(request.getProductIds());
        } catch (IOException e) {
            return ResponseEntity.status(500).build();
        }
        return ResponseEntity.ok(documents);
    }
}
