package com.lucene.lucenedemo.controller;

import com.lucene.lucenedemo.model.Product;
import com.lucene.lucenedemo.service.LuceneService;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexableField;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class ProductIndexer {

    @Autowired
    public LuceneService luceneService;

    private static final Logger logger = LoggerFactory.getLogger(ProductIndexer.class);

    private final IndexWriter indexWriter;
    private final SearcherManager searcherManager;

    @Autowired
    public ProductIndexer(IndexWriter indexWriter, SearcherManager searcherManager) {
        this.indexWriter = indexWriter;
        this.searcherManager = searcherManager;
    }
    public void refreshProductIndex() throws IOException {
        writeToDocument();
        logger.info("---------------------Refresh completed------------------------");
    }

    public void writeToDocument() throws IOException {
        try {
            // Delete all documents
            indexWriter.deleteAll();
            indexWriter.commit();
            // Refresh after deleting the documents from the index
            searcherManager.maybeRefresh();

            // Retrieve product information
            List<Product> products = luceneService.getProducts();
            for (Product product : products) {
                logger.info("Product from API during refresh ------> ");
                Document document = new Document();
                // Add product fields to the document
                document.add(new StringField("PRODUCT_ID", String.valueOf(product.getId()), Field.Store.YES));
                document.add(new TextField("PRODUCT_TITLE", product.getTitle(), Field.Store.YES));
                document.add(new TextField("PRODUCT_DESCRIPTION", product.getDescription(), Field.Store.YES));
                document.add(new TextField("PRODUCT_PRICE", String.valueOf(product.getPrice()), Field.Store.YES));

                logger.info("Document data:");
                for (IndexableField field : document.getFields()) {
                    logger.info("- Field: {}, Value: {}", field.name(), field.stringValue());
                }

                // Add document to the index
                indexWriter.addDocument(document);
            }
            indexWriter.commit();
            searcherManager.maybeRefresh();
        } catch (Exception ex) {
            logger.error("Error in indexing", ex);
        }
    }



//    public Document searchByProductId(String productId) throws IOException {
//        searcherManager.maybeRefresh();
//        IndexSearcher searcher = searcherManager.acquire();
//        try {
//            Query query = new TermQuery(new Term("PRODUCT_ID", productId));
//            TopDocs topDocs = searcher.search(query, 1);
//            if (topDocs.totalHits.value > 0) {
//                return searcher.doc(topDocs.scoreDocs[0].doc);
//            }
//        } finally {
//            searcherManager.release(searcher);
//        }
//        return null;
//    }




//    private Product getProduct() {
//        // Mock implementation - replace with actual logic to get the product
//        return new Product(1, "Product Title", "Product Description", 99.99);
//    }

}
