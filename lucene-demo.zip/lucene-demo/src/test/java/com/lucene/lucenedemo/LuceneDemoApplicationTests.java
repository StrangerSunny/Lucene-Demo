package com.lucene.lucenedemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LuceneDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
